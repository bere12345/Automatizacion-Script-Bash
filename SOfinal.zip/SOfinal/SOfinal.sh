#!/usr/bin/bash

ROJO='\033[0;31m'
CYAN='\033[0;36m'
AMARILLO='\033[0;33m'
BLANCO='\033[0;37m'
NC='\033[0m'

BACKUP_DIR="backups"
LOG_FILE="system_report.log"

respaldoBackup() {
echo -e "${CYAN}Ingrese el directorio a respaldar:${NC}"
read respaldoDir
mkdir -p $BACKUP_DIR
timestamp=$(date +%Y%m%d_%H%M%S)
tar -czf "$BACKUP_DIR/backup_$timestamp.tar.gz" "$respaldoDir"

if [ $? -eq 0 ]; then
echo -e "${BLANCO}Respaldo creado en: $BACKUP_DIR/backup_$timestamp.tar.gz${NC}"
find $BACKUP_DIR -type f -mtime +7 -exec rm {} \;
echo -e "${ROJO}Backups antiguos eliminados.${NC}"
else
echo -e "${ROJO}Error al crear el respaldo.${NC}"
fi
}

informe() {
echo -e "${CYAN}Generando informe del sistema...${NC}"
echo "Informe del Sistema - $(date)" > $LOG_FILE
{
echo "CPU:"
top -bn1 | grep "Cpu(s)"
echo "Memoria:"
free -h
echo "Disco:"
df -h
} >> $LOG_FILE

if [ $? -eq 0 ]; then
echo -e "${BLANCO}Informe guardado en: $LOG_FILE${NC}"
else
echo -e "${ROJO}Error al generar el informe.${NC}"
fi
}

crearUsuario() {
echo -e "${AMARILLO}Como te llamas?${NC}"
read nombreUser
sudo adduser --allow-bad-names $nombreUser

if [ $? -eq 0 ]; then
echo -e "${BLANCO}Usuario creado: $nombreUser${NC}"
else
echo -e "${ROJO}Error al crear el usuario.${NC}"
fi
}

while true; do
echo -e "${AMARILLO}Elegi una opción:${NC}"
echo "1. Respaldo de directorios"
echo "2. Generar informe del sistema"
echo "3. Crear un nuevo usuario"
echo "4. Salir"
read -p "Opción: " option

case $option in
1) respaldoBackup ;;
2) informe ;;
3) crearUsuario ;;
4) echo -e "${ROJO}Saliendo...${NC}" ; exit ;;
*) echo -e "${ROJO}ERROR. Elegi una opcion valida.${NC}" ;;
esac
done
